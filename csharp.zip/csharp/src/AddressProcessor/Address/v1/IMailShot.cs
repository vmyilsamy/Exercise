﻿namespace AddressProcessing.Address.v1
{
    public interface IMailShot
    {
        void SendMailShot(string name, string address);
    }
}