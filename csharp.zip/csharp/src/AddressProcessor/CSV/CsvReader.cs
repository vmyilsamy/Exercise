using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CsvHelper.Configuration;

namespace AddressProcessing.CSV
{
    public class CsvReader : ICsvReader
    {
        private StreamReader _streamReader;

        public void Open(string filename)
        {
            if (!File.Exists(filename))
            {
                throw new FileNotFoundException("Csv file not found", filename);
            }
            var myFileStream = new FileStream(filename, FileMode.Open, FileAccess.Read, FileShare.None);
           _streamReader = new StreamReader(myFileStream);
        }

        public string[] ReadLine()
        {
            var data = _streamReader.ReadLine();

            return !string.IsNullOrEmpty(data) 
                ?  data.Split(new[] { CsvConstants.TabSeparator }, StringSplitOptions.None)
                : new string[] {};
        }

        public IEnumerable<T> ReadAll<T>(string filename)
        {
            if (!File.Exists(filename))
            {
                throw new FileNotFoundException("Csv file not found", filename);
            }

            var csvConfig = new CsvConfiguration
            {
                Delimiter = CsvConstants.TabSeparator,
                HasHeaderRecord = false
            };

            using (var reader = new StreamReader(filename))
            {
                using (CsvHelper.CsvReader csvReader = new CsvHelper.CsvReader(reader, csvConfig))
                {
                    return csvReader.GetRecords<T>().ToList();
                }
            }
        }

        public void Close()
        {
            if(_streamReader != null)
                _streamReader.Close();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_streamReader != null)
                {
                    _streamReader.Close();
                    _streamReader.Dispose();
                    _streamReader = null;
                }
            }
        }
    }
}