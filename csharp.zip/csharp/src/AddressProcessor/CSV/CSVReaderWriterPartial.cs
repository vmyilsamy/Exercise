﻿using System;
using System.Collections.Generic;

namespace AddressProcessing.CSV
{
    public partial class CsvReaderWriter : ICsvReaderWriter
    {
        /*
        1. Left the existing implementation to use 
        */

        private readonly ICsvReader _reader;
        private readonly ICsvWriter _writer;

        //this is to support existing code to compile with an empty constructor
        public CsvReaderWriter()
        {
            _reader = new CsvReader();
            _writer = new CsvWriter();
        }

        //In real life example we will be injecting these components
        public CsvReaderWriter(ICsvReader reader, ICsvWriter writer)
        {
            _reader = reader;
            _writer = writer;
        }

        public void WriteAll<T>(string filename, IEnumerable<T> data)
        {
            _writer.WriteAll(filename, data);
        }

        public IEnumerable<T> ReadAll<T>(string filename)
        {
            return _reader.ReadAll<T>(filename);
        }
    }
}
