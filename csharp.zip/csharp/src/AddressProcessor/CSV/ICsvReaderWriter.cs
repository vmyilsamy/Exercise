using System.Collections.Generic;

namespace AddressProcessing.CSV
{
    public interface ICsvReaderWriter
    {
        void WriteAll<T>(string filename, IEnumerable<T> data);
        IEnumerable<T> ReadAll<T>(string filename);
    }
}