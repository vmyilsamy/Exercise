﻿using System;

namespace AddressProcessing.CSV
{
    /*
        2) Refactor this class into clean, elegant, rock-solid & well performing code, without over-engineering.
           Assume this code is in production and backwards compatibility must be maintained.
    */

    public partial class CsvReaderWriter
    {
        private string _filename;
        private Mode _mode;
        
        [Obsolete("This method is left to support backward compatability. Please use ReadAll<T> / WriteAll<T> for any new implementation")]
        [Flags]
        public enum Mode { Read = 1, Write = 2 };

        [Obsolete("This method is left to support backward compatability. Please use ReadAll<T> / WriteAll<T> for any new implementation")]
        public void Open(string filename, Mode mode)
        {
            _filename = filename;
            _mode = mode;

            switch (mode)
            {
                case Mode.Read:
                    _reader.Open(filename);
                    break;
                case Mode.Write:
                    _writer.Open(filename);
                    break;
                default:
                    throw new Exception("Unknown file mode for " + filename);
            }
        }

        [Obsolete("This method is left to support backward compatability. Please use ReadAll<T> / WriteAll<T> for any new implementation")]
        public void Write(params string[] columns)
        {
            if (_mode != Mode.Write)
            {
                throw new InvalidOperationException(string.Format("File:{0} not opened in write mode, cannot perform write operation", _filename));
            }
            if (columns == null)
            {
                throw new ArgumentNullException("columns");
            }
            if (columns.Length > 2)
            {
                throw new Exception("Unexpected data with either more columns");
            }

            _writer.Write(columns, CsvConstants.TabSeparator);
        }

        [Obsolete("This method is left to support backward compatability. Please use ReadAll<T> / WriteAll<T> for any new implementation")]
        public bool Read(string column1, string column2)
        {
            if (_mode != Mode.Read)
            {
                throw new InvalidOperationException(string.Format("File:{0} not opened in read mode, cannot perform read operation", _filename));
            }
            //On successful read we return true else we throw
            string[] columns = _reader.ReadLine();
            
            //if (columns.Length >= 2)
            //{
            //    column1 = "test";
            //    column2 = columns[1];
            //}
            return (columns.Length >= 2);
        }

        [Obsolete("This method is left to support backward compatability. Please use ReadAll<T> / WriteAll<T> for any new implementation")]
        public bool Read(out string column1, out string column2)
        {
            if (_mode != Mode.Read)
            {
                throw new InvalidOperationException(string.Format("File:{0} not opened in read mode, cannot perform read operation", _filename));
            }

            string[] columns = _reader.ReadLine();

            if (columns.Length >= 2)
            {
                column1 = columns[0];
                column2 = columns[1];
                return true;
            }

            column1 = null;
            column2 = null;

            return false;
        }

        [Obsolete("This method is left to support backward compatability. Please use ReadAll<T> / WriteAll<T> for any new implementation")]
        public void Close()
        {
            if (_reader != null)
            {
                _reader.Close();
            }

            if (_writer != null)
            {
                _writer.Close();
            }
        }
    }
}
