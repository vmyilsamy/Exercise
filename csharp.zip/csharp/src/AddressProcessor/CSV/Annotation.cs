namespace AddressProcessing.CSV
{
    public class Annotation
    {
        public Annotation(string column1, string column2)
        {
            Column1 = column1;
            Column2 = column2;
        }

        public string Column1 { get; private set; }
        public string Column2 { get; private set; }

        public bool IsEmpty()
        {
            return string.IsNullOrEmpty(Column1) && string.IsNullOrEmpty(Column2);
        }
    }
}