using System;
using System.Collections.Generic;
using System.IO;
using CsvHelper.Configuration;

namespace AddressProcessing.CSV
{
    public class CsvWriter : ICsvWriter
    {
        private readonly CsvConfiguration _csvConfig;
        private StreamWriter _streamWriter;

        public CsvWriter()
        {
            _csvConfig = new CsvConfiguration
            {
                Delimiter = CsvConstants.TabSeparator,
                HasHeaderRecord = false,
            };
        }

        public void Open(string filename)
        {
            var myFileStream = new FileStream(filename, FileMode.Append, FileAccess.Write, FileShare.None);
            _streamWriter = new StreamWriter(myFileStream);
        }

        public void Write(string[] columns, string separator)
        {
            var data = string.Join(separator, columns);

            _streamWriter.WriteLine(data);
        }

        public void WriteAll<T>(string filename, IEnumerable<T> data)
        {
            using (var writer = new StreamWriter(filename))
            {
                using (CsvHelper.CsvWriter csvWriter = new CsvHelper.CsvWriter(writer, _csvConfig))
                {
                    csvWriter.WriteRecords(data);
                }
                writer.Close();
            }
        }

        public void Close()
        {
            if (_streamWriter != null)
                _streamWriter.Close();
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_streamWriter != null)
                {
                    _streamWriter.Close();
                    _streamWriter.Dispose();
                    _streamWriter = null;
                }
            }
        }
    }
}