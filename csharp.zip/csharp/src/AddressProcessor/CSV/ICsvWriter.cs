using System;
using System.Collections.Generic;

namespace AddressProcessing.CSV
{
    public interface ICsvWriter : IDisposable
    {
        void Open(string filename);
        void Write(string[] columns, string separator);
        void WriteAll<T>(string filename, IEnumerable<T> data);
        void Close();
    }
}