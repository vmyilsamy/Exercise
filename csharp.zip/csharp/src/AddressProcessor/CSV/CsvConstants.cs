namespace AddressProcessing.CSV
{
    public class CsvConstants
    {
        public const string TabSeparator = "\t";
    }
}