using System;
using System.Collections.Generic;

namespace AddressProcessing.CSV
{
    public interface ICsvReader : IDisposable
    {
        void Open(string filename);
        string[] ReadLine();
        IEnumerable<T> ReadAll<T>(string filename);
        void Close();
    }
}