using System;
using System.IO;
using AddressProcessing.CSV;
using Given.Common;

namespace AddressProcessing.Tests.CsvWriterTests
{
    [Specification]
    public class Open_a_file_to_write_the_contents_successfully : SpecificationBase
    {
        private CsvWriter _csvWriter;
        private Exception _exception;
        private string _filename;
        private string[] _data;
        private string _row1;
        private string _row2;
        private string[] _row2Columns;

        public override void Before()
        {
            _filename = string.Format("testfile_{0}.csv", DateTime.Now.ToString("ddMMyyyyHHmmssfff"));

            _row1 = string.Format("{0}{1}{2}", "col11", CsvConstants.TabSeparator, "col12");
            _row2 = string.Format("{0}{1}{2}", "col21", CsvConstants.TabSeparator, "col22");

            _row2Columns = _row2.Split(new[] { CsvConstants.TabSeparator }, StringSplitOptions.None);

            _data = new [] { _row1 };

            CsvTestHelper.WriteContents(_filename, _data);
        }

        public override void Given()
        {
            _csvWriter = new CsvWriter();
            _csvWriter.Open(_filename);
        }

        public override void When()
        {
            _exception = Catch.Exception(() =>
            {
                _csvWriter.Write(_row2Columns, CsvConstants.TabSeparator);
                _csvWriter.Close();
            });
        }

        [Then]
        public void Should_not_throw_exception()
        {
            _exception.ShouldBeNull();
        }

        [Then]
        public void Should_have_row_two_in_csv()
        {
            var rows = CsvTestHelper.ReadContents(_filename);
            rows.Length.ShouldEqual(2);
        }

        [Then]
        public void Should_have_matching_second_row()
        {
            var rows = CsvTestHelper.ReadContents(_filename);
            rows[1].ShouldEqual(_row2);
        }

        public override void Finally()
        {
            _csvWriter.Close();
            File.Delete(_filename);

            base.Finally();
        }
    }
}