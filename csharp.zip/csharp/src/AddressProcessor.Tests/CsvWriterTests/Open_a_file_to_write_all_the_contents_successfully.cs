using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AddressProcessing.CSV;
using Given.Common;
using NUnit.Framework;

namespace AddressProcessing.Tests.CsvWriterTests
{
    public class Open_a_file_to_write_all_the_contents_successfully : SpecificationBase
    {
        private CsvWriter _csvWriter;
        private Exception _exception;
        private string _filename;
        private IEnumerable<DemoObject> _data;
        private DemoObject _row1;
        private DemoObject _row2;

        public override void Before()
        {
            _filename = string.Format("testfile_{0}.csv", DateTime.Now.ToString("ddMMyyyyHHmmssfff"));

            _row1 = new DemoObject { Column1 = "col11", Column2 = "col12" };
            _row2 = new DemoObject { Column1 = "col21", Column2 = "col22" };

            _data = new List<DemoObject> {_row1, _row2};
        }

        public override void Given()
        {
            _csvWriter = new CsvWriter();
        }

        public override void When()
        {
            _exception = Catch.Exception(() => { _csvWriter.WriteAll(_filename, _data); });
        }

        [Then]
        public void Should_not_throw_exception()
        {
            _exception.ShouldBeNull();
        }

        [Then]
        public void Should_have_row_two_in_csv()
        {
            var rows = CsvTestHelper.ReadContents(_filename);
            rows.Length.ShouldEqual(2);
        }

        [Then]
        public void Should_have_matching_second_row()
        {
            var excepted = _data.Select(a => string.Format("{0}{1}{2}", a.Column1, CsvConstants.TabSeparator, a.Column2));
            var actual = CsvTestHelper.ReadContents(_filename);
            CollectionAssert.AreEqual(excepted, actual);
        }

        public override void Finally()
        {
            base.Finally();
            File.Delete(_filename);
        }
    }
}