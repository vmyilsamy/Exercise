using System;
using System.IO;
using AddressProcessing.CSV;
using Given.Common;

namespace AddressProcessing.Tests.CsvWriterTests
{
    public class Disposing_a_writer_and_trying_to_write_throws_exception : SpecificationBase
    {
        private CsvWriter _csvWriter;
        private Exception _exception;
        private string _filename;

        public override void Before()
        {
            _filename = string.Format("testfile_{0}.csv", DateTime.Now.ToString("ddMMyyyyHHmmssfff"));

            CsvTestHelper.WriteContents(_filename, new[] { "test" });
        }

        public override void Given()
        {
            _csvWriter = new CsvWriter();
            _csvWriter.Open(_filename);
            _csvWriter.Dispose();
        }

        public override void When()
        {
            _exception = Catch.Exception(() => { _csvWriter.Write(new[] { "test" }, CsvConstants.TabSeparator); });
        }

        [Then]
        public void Should_throw_exception()
        {
            _exception.ShouldNotBeNull();
        }

        public override void Finally()
        {
            base.Finally();
            _csvWriter.Close();
            File.Delete(_filename);
        }
    }
}