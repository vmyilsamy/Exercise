using System;
using Given.Common;

namespace AddressProcessing.Tests
{
    public static class Catch
    {
        public static Exception Exception(MethodThatThrows method)
        {
            try
            {
                method();
            }
            catch (Exception ex)
            {
                return ex;
            }
            return null;
        }
    }
}