namespace AddressProcessing.Tests
{
    public class DemoObject
    {
        public string Column1 { get; set; }
        public string Column2 { get; set; }
    }
}