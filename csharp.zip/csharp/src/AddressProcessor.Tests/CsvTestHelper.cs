using System.IO;

namespace AddressProcessing.Tests
{
    internal class CsvTestHelper
    {
        public static void WriteContents(string testfileCsv, string[] lines)
        {
            File.WriteAllLines(testfileCsv, lines);
        }

        public static string[] ReadContents(string testfileCsv)
        {
            return File.ReadAllLines(testfileCsv);
        }
    }
   
}