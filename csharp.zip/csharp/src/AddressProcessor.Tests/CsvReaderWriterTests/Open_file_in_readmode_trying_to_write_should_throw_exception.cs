using System;
using AddressProcessing.CSV;
using Given.Common;
using Moq;

namespace AddressProcessing.Tests.CsvReaderWriterTests
{
    public class Open_file_in_readmode_trying_to_write_should_throw_exception : SpecificationBase
    {
        private CsvReaderWriter _readerWriter;
        private Exception _exception;
        private Mock<ICsvReader> _csvReaderMock;
        private Mock<ICsvWriter> _csvWriterMock;

        public override void Before()
        {
            _csvReaderMock = new Mock<ICsvReader>();
            _csvWriterMock = new Mock<ICsvWriter>();

            _readerWriter = new CsvReaderWriter(_csvReaderMock.Object, _csvWriterMock.Object);
        }

        public override void Given()
        {
            _readerWriter.Open("testfile.csv", CsvReaderWriter.Mode.Read);
        }

        public override void When()
        {
            _exception = Catch.Exception(() => _readerWriter.Write(new[] { "value1", "value2" }));
        }
        
        [Then]
        public void Should_throw_exception()
        {
            _exception.ShouldNotBeNull();
        }

        [Then]
        public void csvWriter_write_was_never_called()
        {
            _csvWriterMock.Verify(w => w.Write(It.IsAny<string[]>(), It.IsAny<string>()), Times.Never);
        }

    }
}