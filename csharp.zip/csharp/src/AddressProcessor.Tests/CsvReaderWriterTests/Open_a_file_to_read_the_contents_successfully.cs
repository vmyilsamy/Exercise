using System;
using AddressProcessing.CSV;
using Given.Common;
using Moq;

namespace AddressProcessing.Tests.CsvReaderWriterTests
{
    public class Open_a_file_to_read_the_contents_successfully : SpecificationBase
    {
        private CsvReaderWriter _readerWriter;
        private Exception _exception;
        private Mock<ICsvReader> _csvReaderMock;
        private Mock<ICsvWriter> _csvWriterMock;
        private bool _success;
        string _column1;
        string _column2;

        public override void Before()
        {
            _csvReaderMock = new Mock<ICsvReader>();
            _csvWriterMock = new Mock<ICsvWriter>();

            _csvReaderMock.Setup(r => r.ReadLine()).Returns(new string[] {"test1", "test2" });

            _readerWriter = new CsvReaderWriter(_csvReaderMock.Object, _csvWriterMock.Object);
        }

        public override void Given()
        {
            _readerWriter.Open("testfile.csv", CsvReaderWriter.Mode.Read);
        }

        public override void When()
        {
            _exception = Catch.Exception(() =>
            {
                _success = _readerWriter.Read(out _column1, out _column2);
            });
        }
        
        [Then]
        public void Should_not_throw_exception()
        {
            _exception.ShouldBeNull();
        }

        [Then]
        public void Should_have_read_successfully()
        {
            _success.ShouldBeTrue();
        }

        [Then]
        public void Should_have_called_readline_once()
        {
            _csvReaderMock.Verify(r => r.ReadLine(), Times.Once);
        }

        [Then]
        public void Column1_should_have_value_test1()
        {
            _column1.ShouldEqual("test1");
        }

        [Then]
        public void Column2_should_have_value_test2()
        {
            _column2.ShouldEqual("test2");
        }
    }
}