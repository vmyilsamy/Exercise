using System;
using AddressProcessing.CSV;
using Given.Common;
using Moq;


namespace AddressProcessing.Tests.CsvReaderWriterTests
{
    public class Open_a_file_to_write_the_contents_successfully : SpecificationBase
    {
        private CsvReaderWriter _readerWriter;
        private Exception _exception;
        private Mock<ICsvReader> _csvReaderMock;
        private Mock<ICsvWriter> _csvWriterMock;
        string _column1;
        string _column2;

        public override void Before()
        {
            _csvReaderMock = new Mock<ICsvReader>();
            _csvWriterMock = new Mock<ICsvWriter>();

            _readerWriter = new CsvReaderWriter(_csvReaderMock.Object, _csvWriterMock.Object);
        }

        public override void Given()
        {
            _readerWriter.Open("testfile.csv", CsvReaderWriter.Mode.Write);
        }

        public override void When()
        {
            _exception = Catch.Exception(() => _readerWriter.Write(new[] { "value1", "value2" }));
        }

        [Then]
        public void Should_not_throw_exception()
        {
            _exception.ShouldBeNull();
        }

        [Then]
        public void Should_have_called_write_once()
        {
            _csvWriterMock.Verify(r => r.Write(It.IsAny<string[]>(), It.IsAny<string>()), Times.Once);
        }
    }
}