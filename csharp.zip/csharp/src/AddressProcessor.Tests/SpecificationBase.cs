using NUnit.Framework;

namespace AddressProcessing.Tests
{
    public abstract class SpecificationBase
    {
        /// <summary>
        /// Execute the abstract Given and When methods once for all the Then test cases
        /// </summary>
        [TestFixtureSetUp]
        public void Setup()
        {
            Before();
            Given();
            When();
        }

        public virtual void Before()
        {
            
        }
        public abstract void Given();
        public abstract void When();

        [TestFixtureTearDown]
        public void Dispose()
        {
            Finally();
        }

        /// <summary>
        /// Virtual method to allow any resource cleanup as required (disposal)
        /// </summary>
        public virtual void Finally()
        {
        }
    }

    public class SpecificationAttribute : TestFixtureAttribute { }
    public class ThenAttribute : TestAttribute { }
}