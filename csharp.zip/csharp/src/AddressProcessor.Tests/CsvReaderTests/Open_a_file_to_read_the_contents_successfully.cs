using System;
using System.IO;
using AddressProcessing.CSV;
using Given.Common;

namespace AddressProcessing.Tests.CsvReaderTests
{
    [Specification]
    public class Open_a_file_to_read_the_contents_successfully : SpecificationBase
    {
        private CsvReader _csvReader;
        private Exception _exception;
        private string _filename;
        private string[] _data;
        private string[] _actualLines;
        private string _row1;
        private string _row2;

        public override void Before()
        {
            _filename = string.Format("testfile_{0}.csv", DateTime.Now.ToString("ddMMyyyyHHmmssfff"));

            _row1 = string.Format("{0}{1}{2}", "col11", CsvConstants.TabSeparator, "col12");
            _row2 = string.Format("{0}{1}{2}", "col21", CsvConstants.TabSeparator, "col22");

            _data = new [] { _row1, _row2 };

            CsvTestHelper.WriteContents(_filename, _data);
        }

        public override void Given()
        {
            _csvReader = new CsvReader();
            _csvReader.Open(_filename);
        }

        public override void When()
        {
            _exception = Catch.Exception(() => { _actualLines = _csvReader.ReadLine(); });
        }

        [Then]
        public void Should_not_throw_exception()
        {
            _exception.ShouldBeNull();
        }

        [Then]
        public void Should_have_matching_first_line()
        {
            _row1.ShouldEqual(string.Join(CsvConstants.TabSeparator, _actualLines));
        }

        public override void Finally()
        {
            _csvReader.Close();
            File.Delete(_filename);

            base.Finally();
        }
    }
}