using System;
using System.IO;
using AddressProcessing.CSV;
using Given.Common;

namespace AddressProcessing.Tests.CsvReaderTests
{
    public class Opening_a_file_after_Open_and_close_operation : SpecificationBase
    {
        private CsvReader _csvReader;
        private Exception _exception;
        private string _filename;

        public override void Before()
        {
            _filename = string.Format("testfile_{0}.csv", DateTime.Now.ToString("ddMMyyyyHHmmssfff"));

            CsvTestHelper.WriteContents(_filename, new [] {"test"});
        }

        public override void Given()
        {
            _csvReader = new CsvReader();
            _csvReader.Open(_filename);
            _csvReader.Close();
        }

        public override void When()
        {
            _exception = Catch.Exception(() => { _csvReader.Open(_filename); });
        }

        [Then]
        public void Should_not_throw_exception()
        {
            _exception.ShouldBeNull();
        }

        public override void Finally()
        {
            base.Finally();
            _csvReader.Close();
            File.Delete(_filename);
        }
    }
}